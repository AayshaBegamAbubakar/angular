export class mentor{
    userName:string;
    email:string;
    password:string;
    gender:string;
    address:string;
    contactNumber:string;
    role:string;
    linkedInUrl :string;
    trainingCompleted :string;
    skills:string;
    years : string;
    slot : string;

}