export class User{
    userName:string;
    email:string;
    password:string;
    gender:string;
    address:string;
    contactNumber:string;
}