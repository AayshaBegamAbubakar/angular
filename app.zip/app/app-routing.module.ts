import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserRegistrationComponent } from './user-registration/user-registration.component';
import { LoginComponent } from './login/login.component';
import { MentorRegistrationComponent } from './mentor-registration/mentor-registration.component';

const routes: Routes = [
  {path:'' , component:LoginComponent,pathMatch:'full'},
  {path:'UserRegistration' , component:UserRegistrationComponent},
  {path:'LoginComponent' , component:LoginComponent},
  {path:'MentorRegistration' , component:MentorRegistrationComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],

  exports: [RouterModule]
})
export class AppRoutingModule { }
