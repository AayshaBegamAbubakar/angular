import { Component, OnInit } from '@angular/core';
import { User } from '../model/User';
import { UserService } from '../service/user.service';
import { LoginComponent } from '../login/login.component';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-registration',
  templateUrl: './user-registration.component.html',
  styleUrls: ['./user-registration.component.css']
})
export class UserRegistrationComponent implements OnInit {
  user: User =new User();
  insert:any;
 submitted=false;
  constructor(private router: Router,private userService :UserService) { }

  ngOnInit() {
  }
 
  save(){
    console.log(this.submitted);
    this.userService.createUser(this.user)
    .subscribe(data=>this.insert=data,error=>console.log(error));
    this.user=new User();
    console.log(this.insert);
   
      console.log('aassa');
      this.router.navigate(['LoginComponent']);
    
  }
  onSubmit(){
    console.log(this.submitted);
    this.submitted=true;
    this.save();
  }
}
